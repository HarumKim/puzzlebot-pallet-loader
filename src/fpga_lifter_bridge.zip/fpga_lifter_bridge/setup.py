from setuptools import find_packages, setup

package_name = 'fpga_lifter_bridge'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='mateo',
    maintainer_email='neronf123@gmail.com',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'lifter_spi_node = fpga_lifter_bridge.lifter_spi_node:main',
            'lifter_keyboard_test = fpga_lifter_bridge.lifter_keyboard_test:main',
            'forklift_spi_node = fpga_lifter_bridge.forklift_spi_node:main',
        ],
    },
)
